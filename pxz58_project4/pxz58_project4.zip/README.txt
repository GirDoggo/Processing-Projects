I am using 2 slip days for this project.

This program is a physical particle simulation of a ball in a box. The user can control this ball by clicking
on it and dragging it to change its position. Before or while dragging the ball, the user can right click on the 
ball in order to release it with added force when it is next released. The magnitude of this force can be increased
by dragging the ball further from its original position before being clicked before releasing it. The impulse of this
force can be increased by rightclicking more times. Each right click increases the impulse by 5 times. If the ball 
is ever dragged out of bounds by the user, it will automatically reset to the center of the box.